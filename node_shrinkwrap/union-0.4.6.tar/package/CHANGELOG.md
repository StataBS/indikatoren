
0.3.4 / 2012-07-24
==================

  * Added SPDY support
  * Added http redirect utility function

