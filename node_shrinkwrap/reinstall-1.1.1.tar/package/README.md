# reinstall

Reinstall package's node modules without cache.

* Removes node_modules directory
* Clean's NPM cache
* Install's modules from package.json

## Install

```
npm install reinstall -g
```

## Usage

```
reinstall
```

That's it.