General format is: contributor, github handle, email. In some cases, the
contributor field is an organization instead of an actual person---this is for
cases where the work was done on behalf of the organization, ie as part of
their job. In others, no contributor field and/or email is shown---this is
because this list was partially (mostly) reconstructed from github commit
information and the person's real life name and email are unknown.

Listed in no particular order:

* Joshua Holbrook @jfhbrook <josh.holbrook@gmail.com>
* Jon Ege Ronnenberg @dotnetCarpenter <jon.ronnenberg@gmail.com>
* James Halliday @substack <substack@gmail.com>
* Jonah Ruiz @jonahoffline <jonah@pixelhipsters.com>
* Jacob Burden @jekrb <Jacob.JW.Burden@gmail.com>
* @leesei
* @SirAnthony
* Frank Mecklenburg @yfr <mecklenburg@ubilabs.net>
* @curimit <curimit@gmail.com>
* Dominic Tarr @dominictarr
* Chew Choon Keat @choonkeat <choonkeat@gmail.com>
* Lars Kappert @webpro <lars@webpro.nl>
* Alan Reyes @KuttKatrea <kutt@katrea.net>
* Colin Fallon @colinf
* Charlie Robbins @indexzero
* Ville Salonen @VilleSalonen
* Tom Steele @tomsteele <thomasjsteele@gmail.com>
* Maciej Małecki @mmalecki <me@mmalecki.com>
* Chris Bannister @Zariel <c.bannister@gmail.com>
* Shinnosuke Watanabe @shinnn <snnskwtnb@gmail.com>
* Adam Brady @SomeoneWeird <adam@boxxen.org>
* Christian Howe @coderarity
* Arnaud @amelon
* Gilad Peleg @pgilad <giladp007@gmail.com>
* Brad Dunbar @braddunbar <dunbarb2@gmail.com>
* Google Inc. via Jeremy Banks @jre-g <jre@google.com>
* @sundippatel
* Arjan van Wijk @ThaNarie <thanarie@gmail.com>
* Mathias Buus @mafintosh <mathiasbuus@gmail.com>
* Farrin Reid @blakmatrix <blakmatrix@gmail.com>
* Tõnis Tiigi @tonistiigi <tonistiigi@gmail.com>
* Maksim Lin @maks <maks@manichord.com>
* Jan Nicklas @jantimon
* David Cox @losttime <losttime.shuffle@gmail.com>
* Bill Ticehurst @billti <billti@hotmail.com>
* Vincent Voyer @vvo <vincent.voyer@gmail.com>
* @helloyou2012 <helloyou2012@gmail.com>
* Domenic Denicola @domenic <d@domenic.me>
* Maxim Ivanov @redbaron <ivanov.maxim@gmail.com>
* Oliver Joseph Ash @OliverJAsh <oliverjash@gmail.com>
* Benjamin Tan @d10 <demoneaux@gmail.com>
* D Scott Boyce @scobo
* Zach Bruggerman @remixz <mail@bruggie.com>
* Mathias Bynens @mathiasbynens
* Chris Lee @clee <clee@mg8.org>
* Josh Duff @TehShrike
* Cam Wiegert @camwiegert <cam@camwiegert.com>
* Josh Gillies @joshgillies <github@joshgilli.es>
